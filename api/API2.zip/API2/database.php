<?php
define('DB_HOST',     '10.1.1.104');
define('DB_USER',     'user_cloud');
define('DB_PASSWORD', 'Rahasia123!');
define('DB_NAME',     'db_cafe');

function getConnection() {
    $conn = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);

    if (!$conn) {
        response(500, [
            "status"  => "error",
            "message" => "Koneksi database gagal: " . mysqli_connect_error()
        ]);
    }

    mysqli_set_charset($conn, "utf8");
    return $conn;
}
?>